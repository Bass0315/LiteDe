/*
  Copyright (c) 2014-2015 Arduino LLC.  All right reserved.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the GNU Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#pragma once

// The definitions here needs a SAMD core >=1.6.10
#define ARDUINO_SAMD_VARIANT_COMPLIANCE 10610

/*----------------------------------------------------------------------------
 *        Definitions
 *----------------------------------------------------------------------------*/

/** Frequency of the board main oscillator */
#define VARIANT_MAINOSC (32768ul)

/** Master clock frequency */
#define VARIANT_MCK (48000000ul)

/** Clock generators allocation */
//  Generator | allocation-place | source   | input-freq | output-freq | comment
//      0         startup.c        DFLL48M      48MHz        48MHz      GENERIC_CLOCK_GENERATOR_MAIN
//      1         startup.c        32KHz Ext    32768Hz      32768Hz    GENERIC_CLOCK_GENERATOR_XOSC32K
//      2       Power Reset        OSCULP32K    32768Hz      32768Hz    GENERIC_CLOCK_GENERATOR_OSCULP32K
//                                                                      also used by watchdog
//      3         startup.c        Inner RC     8MHz         8MHz       GENERIC_CLOCK_GENERATOR_OSC8M
//      4         startup.c        DFLL48M      48MHz        24MHz      GENERIC_CLOCK_GENERATOR_WIRE
//      5
//      6       lib/EnergySaving   OSCULP32K    32768Hz      32768Hz
//      7
#define GENERIC_CLOCK_GENERATOR_WDT (2u)

/*----------------------------------------------------------------------------
 *        Headers
 *----------------------------------------------------------------------------*/

#include "WVariant.h"

#ifdef __cplusplus
#include "SERCOM.h"
#include "Uart.h"
#endif // __cplusplus

/*----------------------------------------------------------------------------
 *        Pins
 *----------------------------------------------------------------------------*/

// Number of pins defined in PinDescription array
#define PINS_COUNT (sizeof(g_APinDescription) / sizeof(g_APinDescription[0]))
#define NUM_DIGITAL_PINS (2u)
#define NUM_ANALOG_INPUTS (2u)
#define NUM_ANALOG_OUTPUTS (0u)
#define analogInputToDigitalPin(p) ((p < 6u) ? (p) + 14u : -1)

#define digitalPinToPort(P) (&(PORT->Group[g_APinDescription[P].ulPort]))
#define digitalPinToBitMask(P) (1 << g_APinDescription[P].ulPin)
//#define analogInPinToBit(P)        ( )
#define portOutputRegister(port) (&(port->OUT.reg))
#define portInputRegister(port) (&(port->IN.reg))
#define portModeRegister(port) (&(port->DIR.reg))
#define digitalPinHasPWM(P) (g_APinDescription[P].ulPWMChannel != NOT_ON_PWM || g_APinDescription[P].ulTCChannel != NOT_ON_TIMER)

/*
 * digitalPinToTimer(..) is AVR-specific and is not defined for SAMD
 * architecture. If you need to check if a pin supports PWM you must
 * use digitalPinHasPWM(..).
 *
 * https://github.com/arduino/Arduino/issues/1833
 */
// #define digitalPinToTimer(P)

// LEDs
// ----
#define PIN_LED_13 (13u)
#define PIN_LED PIN_LED_13
#define LED_BUILTIN PIN_LED
#define PIN_LED_R (11)
#define PIN_LED_G (12)
#define PIN_LED_B (13)

/* HIGH -- hw control, LOW -- control by PIN_LED_G */
#define PIN_LED_G_HW (10)

/*
 * Digital pins
 */
#define D1 (1u)
#define D2 (2u)

#define PIN_DC_PWR    (30)
#define PIN_OV_12V    (31)
#define PIN_OV_5V     (32)
#define PIN_OV_3V3    (33)

/*
 * GCLK pins
 */
#define PIN_GCLK1_32KHZ (39)
#define PIN_GCLK4_24MHZ (40)

/*
 * Test Point
 */
#define PIN_TP9  (42)             // TP9,  PA12
#define PIN_TP57 PIN_GCLK1_32KHZ  // TP57, PB23

/*
 * Analog pins
 */
#define PIN_A0 (0u) // Not a Analog Pin
#define PIN_A1 (3u) //
#define PIN_A2 (4u) //
#define PIN_A3 (5u) //

static const uint8_t A0 = PIN_A0;
static const uint8_t A1 = PIN_A1;
static const uint8_t A2 = PIN_A2;
static const uint8_t A3 = PIN_A3;

// analogRead() used pins
enum {
  PIN_TEMP = 34,
  PIN_BANDGAP,
  PIN_SCALEDCOREVCC,
  PIN_SCALEDIOVCC,
  PIN_DAC,
};

#define AIN1 PIN_A1
#define AIN2 PIN_A2
#define C2A PIN_A3

#define PIN_DAC0 (PIN_A2)

#define ADC_RESOLUTION 12

// /*
//  * SPI Interfaces
//  */
#define SPI_INTERFACES_COUNT 2

// SPI0 CANBUS
#define PIN_SPI_MOSI (18u)
#define PIN_SPI_MISO (19u)
#define PIN_SPI_SCK (20u)
#define PERIPH_SPI sercom0
#define PAD_SPI_TX SPI_PAD_0_SCK_3 // MOSI / SCK
#define PAD_SPI_RX SERCOM_RX_PAD_1 // MISO

static const uint8_t SS = 21u;
static const uint8_t MOSI = PIN_SPI_MOSI;
static const uint8_t MISO = PIN_SPI_MISO;
static const uint8_t SCK = PIN_SPI_SCK;

#define CANBUS SPI
#define CANBUS_PIN_MOSI PIN_SPI_MOSI
#define CANBUS_PIN_MISO PIN_SPI_MISO
#define CANBUS_PIN_SCK PIN_SPI_SCK
#define CANBUS_PIN_SS SS
#define CANBUS_PIN_INT (22u)
#define CANBUS_PIN_GCLK (23u)

// SPI1 INTERFACE
#define PIN_SPI1_MISO (14u)
#define PIN_SPI1_SCK (15u)
#define PIN_SPI1_MOSI (16u)
#define PERIPH_SPI1 sercom1
#define PAD_SPI1_TX SPI_PAD_3_SCK_1 // MOSI / SCK
#define PAD_SPI1_RX SERCOM_RX_PAD_2 // MISO

static const uint8_t SS1 = 17u;
static const uint8_t MOSI1 = PIN_SPI1_MOSI;
static const uint8_t MISO1 = PIN_SPI1_MISO;
static const uint8_t SCK1 = PIN_SPI1_SCK;

/*
 * Wire Interfaces
 */
#define WIRE_INTERFACES_COUNT 1

// I2C hardware rising time
#define WIRE_RISE_TIME_NANOSECONDS 650 /* 650ns */

// I2C generic clock generator
#define GENERIC_CLOCK_GENERATOR_WIRE (4u)

// "external" public i2c interface
#define PIN_WIRE_SDA (8u)
#define PIN_WIRE_SCL (9u)
#define PERIPH_WIRE sercom3
#define WIRE_IT_HANDLER SERCOM3_Handler
static const uint8_t SDA = PIN_WIRE_SDA;
static const uint8_t SCL = PIN_WIRE_SCL;

// USB
// ---
#define PIN_USB_HOST_ENABLE (27ul)
#define PIN_USB_DM (28ul)
#define PIN_USB_DP (29ul)

// I2S Interfaces
// --------------
#define I2S_INTERFACES_COUNT 0

// Serial ports
// ------------
#ifdef __cplusplus
#include "SERCOM.h"
#include "Uart.h"

// Instances of SERCOM
extern SERCOM sercom0;
extern SERCOM sercom1;
extern SERCOM sercom2;
extern SERCOM sercom3;
extern SERCOM sercom4;
extern SERCOM sercom5;

// Serial1 J4.UART
extern Uart Serial1;
#define PIN_SERIAL1_TX (6ul)
#define PIN_SERIAL1_RX (7ul)
#define PAD_SERIAL1_TX (UART_TX_PAD_2)
#define PAD_SERIAL1_RX (SERCOM_RX_PAD_3)

// Serial2 RS485
extern Uart Serial2;
#define PIN_SERIAL2_TX (25ul)
#define PIN_SERIAL2_RX (26ul)
#define PAD_SERIAL2_TX (UART_TX_PAD_2)
#define PAD_SERIAL2_RX (SERCOM_RX_PAD_3)
#define RS485 Serial2
#define RS485_TX (25ul)
#define RS485_RX (26ul)
#define RS485_DE (24ul)
#endif // __cplusplus

// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_USBVIRTUAL SerialUSB
#define SERIAL_PORT_MONITOR SerialUSB
#define SERIAL_PORT_HARDWARE Serial1
#define SERIAL_PORT_HARDWARE_OPEN Serial1

// Alias Serial to SerialUSB
#define Serial SerialUSB



// IOTEXP Board Revision
// select a board by enable a specific #define line
//#define _IOTEXP_REV_EV1 1
#define _IOTEXP_REV_EV2 1


#if !defined(_IOTEXP_REV_EV1) && !defined(_IOTEXP_REV_EV2)
#error should select a board revision at least
#endif
#if defined(_IOTEXP_REV_EV1) && defined(_IOTEXP_REV_EV2)
#error only select a single board revision
#endif

#if defined(_IOTEXP_REV_EV2) && _IOTEXP_REV_EV2
#define PIN_VREFA (41)
#endif

