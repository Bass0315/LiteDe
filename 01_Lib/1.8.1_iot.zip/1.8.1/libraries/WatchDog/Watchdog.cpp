/*
 filename: Watchdog.cpp
 author: Sergio Vargas
 date last modified: 05/01/2018
 platform: ARM M0 (SAMD21)
 SAMD21 watchdog timer library source file.
 */

#include "Watchdog.h"

Watchdog::Watchdog(){
}

Watchdog::Watchdog(uint8_t timeout){
	WDT->CTRL.reg = 0; // Se desactiva WDT
	WDTsync(); // Sincronizar para no perder configuración

	//Establece la división del generador de relojes (GCLKGEN2/2^5)
	GCLK->GENDIV.reg = GCLK_GENDIV_DIV(0x4) | GCLK_GENDIV_ID(GENERIC_CLOCK_GENERATOR_WDT);
	GCLKsync(); // Sincronizar para no perder configuración

	//Relaciona OSCULP32K con GCLKGEN2
	GCLK->GENCTRL.reg = GCLK_GENCTRL_DIVSEL |
	                    GCLK_GENCTRL_GENEN |
	                    GCLK_GENCTRL_SRC_OSCULP32K |
	                    GCLK_GENCTRL_ID(GENERIC_CLOCK_GENERATOR_WDT);
	GCLKsync(); // Sincronizar para no perder configuración

	//Relaciona GCLKGEN2 con GCLK_WDT
	GCLK->CLKCTRL.reg = GCLK_CLKCTRL_CLKEN |
	                    GCLK_CLKCTRL_GEN(GENERIC_CLOCK_GENERATOR_WDT) |
	                    GCLK_CLKCTRL_ID_WDT;
	GCLKsync(); // Sincronizar para no perder configuración

	// so, GCLK_WDT = 32768Hz / 32 = 1024Hz
	//     Max timeout = 16384 cycles / 1024 Hz = 16 Seconds
	WDT->CONFIG.reg = min(timeout, wdtTimeout);

	//Activar WDT, Normal Mode(Not Window Mode)
	WDT->CTRL.reg = WDT_CTRL_ENABLE;
	WDTsync(); // Sincronizar para no perder configuración
}

//Sincronización del WDT
void Watchdog::WDTsync()
{
	while (WDT->STATUS.bit.SYNCBUSY == 1);
}

//Sincronización del GCLK
void Watchdog::GCLKsync()
{
	while (GCLK->STATUS.bit.SYNCBUSY == 1);
}

// reset del WDT (DEBE ser con 0xA5)
void Watchdog::resetWDT()
{
	WDT->CLEAR.reg = 0xA5;
	WDTsync();

}

// reset del sistema (DIFERENTE de 0xA5)
void Watchdog::systemReset()
{
	WDT->CLEAR.reg = 0x00;
	WDTsync();
}

// desactivar WDT
void Watchdog::disableWDT()
{
	WDT->CTRL.reg = 0;
	WDTsync();
}
